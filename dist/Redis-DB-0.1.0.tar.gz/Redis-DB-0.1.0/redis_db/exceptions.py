class ObjDoesNotExist(Exception):
    pass

